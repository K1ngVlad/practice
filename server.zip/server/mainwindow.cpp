#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<QDebug>
#include <QSerialPort>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setAddress(0);
    setStatus(0);

    serial = new QSerialPort(this);

    connect(serial, SIGNAL(readyRead()), this, SLOT(serialRecieve()));

    setDefaultUI();
}

MainWindow::~MainWindow()
{
    delete ui;

    serial->close();
    delete serial;
}

void MainWindow::setStatus(char status) {
    this->status = status;
}

void MainWindow::setAddress(char address) {
    this->address = address;
}

void MainWindow::setDefaultUI() {
    ui->stopButton->setDisabled(true);
    ui->startButton->setDisabled(false);
    ui->portSelect->setDisabled(false);
    ui->speedSelect->setDisabled(false);
    ui->statusLabel->setText("Выключен");

    ui->tempSlider->setMinimum(0);
    ui->tempSlider->setMaximum(720);
    ui->voltageSlider->setMinimum(0);
    ui->voltageSlider->setMaximum(2000);

    ui->portSelect->clear();

    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts()) {
        QSerialPort port;
        port.setPort(info);
        ui->portSelect->addItem(info.portName());
        if(port.open(QIODevice::ReadWrite)) {
            qDebug() << "Название: " + info.portName() + " " + info.description() + " " + info.manufacturer() << "\n";
        }
    }

    ui->speedSelect->clear();

    ui->speedSelect->addItem("1200 baud");
    ui->speedSelect->addItem("2400 baud");
    ui->speedSelect->addItem("4800 baud");
    ui->speedSelect->addItem("9600 baud");
    ui->speedSelect->addItem("19200 baud");
    ui->speedSelect->addItem("38400 baud");
    ui->speedSelect->addItem("57600 baud");
    ui->speedSelect->addItem("115200 baud");

    ui->speedSelect->setCurrentIndex(ui->speedSelect->findText("9600 baud"));

    ui->rangeSelect->clear();

    ui->rangeSelect->addItem("Штатный");
    ui->rangeSelect->addItem("Контроль");
    ui->rangeSelect->addItem("Калибровка");
    ui->rangeSelect->addItem("Загрузчик");

    ui->tempValue->setNum(TEMP_MIN + ui->tempSlider->value() * TEMP_STEP);
    ui->voltageValue->setNum(VOLTAGE_MIN + ui->voltageSlider->value() * VOLTAGE_STEP);
}

QByteArray MainWindow::getError(char action = 0) {
    QByteArray data;
    data.resize(CONFIG_SIZE);
    data[0] = address;
    data[1] = action;
    data[2] = 1;
    data[3] = 0;
    return data;
}

QByteArray MainWindow::getConnectData() {
    QByteArray data;
    data.resize(CONFIG_SIZE);
    data[0] = address;
    data[1] = 0;
    data[2] = 0;
    data[3] = 0;

    return data;
}

QByteArray MainWindow::getSuccessData() {
    QByteArray data;
    data.resize(CONFIG_SIZE);
    data[0] = address;
    data[1] = 2;
    data[2] = 0;
    data[3] = 0;

    return data;
}

QByteArray MainWindow::getData() {
    QByteArray data;
    data.resize(CONFIG_SIZE + DATA_SIZE);
    data[0] = address;
    data[1] = 1;
    data[2] = 0;
    data[3] = (char) DATA_SIZE;

    data[4] = ui->rangeSelect->currentIndex();

    data[5] = 0;
    data[5] = ui->moduleServiceability->isChecked() ? (data[5] | 1 << 0) : data[5];
    data[5] = ui->sourceServiceability->isChecked() ? (data[5] | 1 << 1) : data[5];
    data[5] = ui->romServiceability->isChecked() ? (data[5] | 1 << 2) : data[5];
    data[5] = ui->tempServiceability->isChecked() ? (data[5] | 1 << 3) : data[5];
    data[5] = ui->voltageServiceability->isChecked() ? (data[5] | 1 << 4) : data[5];
    data[5] = ui->firstAttenuatorServiceability->isChecked() ? (data[5] | 1 << 5) : data[5];
    data[5] = ui->secondAttenuatorServiceability->isChecked() ? (data[5] | 1 << 6) : data[5];
    data[5] = ui->reserveServiceability->isChecked() ? (data[5] | 1 << 7) : data[5];

    int temp = ui->tempSlider->value();
    unsigned char* tempBytes = (unsigned char*)&temp;
    data[6] = tempBytes[0];
    data[7] = tempBytes[1];

    int voltage = ui->voltageSlider->value();
    unsigned char* voltageBytes = (unsigned char*)&voltage;
    data[8] = voltageBytes[0];
    data[9] = voltageBytes[1];

    data[10] = (unsigned char) ui->majorVersionCount->value();
    data[11] = (unsigned char) ui->minorVersionCount->value();

    return data;
}

void MainWindow::displayData(QByteArray & ba) {
    const int DATA_SIZE = ba[3];

    int firstAtt = 0;
    int secondAtt = 0;

    for(int i = 0; i < DATA_SIZE; i++) {
        switch (i) {
            case 0:
            ui->state11->setText((1 << 0 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state12->setText((1 << 1 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state13->setText((1 << 2 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state14->setText((1 << 3 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state15->setText((1 << 4 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state16->setText((1 << 5 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state17->setText((1 << 6 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state18->setText((1 << 7 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
                break;
            case 1:
            ui->state21->setText((1 << 0 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state22->setText((1 << 1 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state23->setText((1 << 2 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state24->setText((1 << 3 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state25->setText((1 << 4 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state26->setText((1 << 5 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state27->setText((1 << 6 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
            ui->state28->setText((1 << 7 & ba[DATA_INDEX + i]) ? "Вкл" : "Выкл");
                break;
            case 2:
                firstAtt = (unsigned char) ba[DATA_INDEX + i];
                break;
            case 3:
                firstAtt = firstAtt + ((unsigned char) ba[DATA_INDEX + i]) * 256;
                break;
            case 4:
                secondAtt = (unsigned char) ba[DATA_INDEX + i];
                break;
            case 5:
                secondAtt = secondAtt + ((unsigned char) ba[DATA_INDEX + i]) * 256;
                break;
        }
    }
    ui->firstAtteniatorVal->setNum(ATT_MIN + firstAtt * ATT_STEP);
    ui->secondAtteniatorVal->setNum(ATT_MIN + secondAtt * ATT_STEP);
}

void MainWindow::on_startButton_clicked()
{
    QString portName = ui->portSelect->currentText();
    char address = (char) ui->addressInput->text().toInt();
    ui->startButton->setDisabled(true);
    ui->stopButton->setDisabled(false);
    ui->addressInput->setDisabled(true);
    ui->portSelect->setDisabled(true);
    ui->speedSelect->setDisabled(true);
    ui->statusLabel->setText("Запущен");
    setStatus(1);
    setAddress(address);
    serial->setPortName(portName);

    switch (ui->speedSelect->currentIndex()) {
        case 0:
            serial->setBaudRate(QSerialPort::Baud1200);
            break;
        case 1:
            serial->setBaudRate(QSerialPort::Baud2400);
            break;
        case 2:
            serial->setBaudRate(QSerialPort::Baud4800);
            break;
        case 3:
            serial->setBaudRate(QSerialPort::Baud9600);
            break;
        case 4:
            serial->setBaudRate(QSerialPort::Baud19200);
            break;
        case 5:
            serial->setBaudRate(QSerialPort::Baud38400);
            break;
        case 6:
            serial->setBaudRate(QSerialPort::Baud57600);
            break;
        case 7:
            serial->setBaudRate(QSerialPort::Baud115200);
            break;
        default:
            serial->setBaudRate(QSerialPort::Baud9600);
    }

    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->open(QIODevice::ReadWrite);
}

void MainWindow::on_stopButton_clicked()
{
    setDefaultUI();
    setAddress(0);
    setStatus(0);
    serial->close();
}

void MainWindow::serialRecieve() {
    if(status == 0) return;

    QByteArray ba = serial->readAll();

    if(address && (ba[0] == address)) {
        switch (ba[1]) {
            case (char) 0:
                if(ba[2] == (char) 0) {
                    setStatus(2);
                    ui->statusLabel->setText("Подключён");
                    serial->write(getConnectData());
                }
                else {
                    serial->write(getError(ba[2]));
                }
                break;
            case (char) 1:
                if(ba[2] == (char) 0) {
                    serial->write(getData());
                }
                else {
                    serial->write(getError(ba[2]));
                }
                break;
            case (char) 2:
                if(ba[2] == (char) 1) {
                    displayData(ba);
                    serial->write(getSuccessData());
                }
                else {
                    serial->write(getError(ba[2]));
                }
                break;
        }
    }

}

void MainWindow::on_tempSlider_valueChanged(int value)
{
    ui->tempValue->setNum(TEMP_MIN + value * TEMP_STEP);
}

void MainWindow::on_voltageSlider_valueChanged(int value)
{
    ui->voltageValue->setNum(VOLTAGE_MIN + value * VOLTAGE_STEP);
}
