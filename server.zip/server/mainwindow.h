#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QSerialPortInfo>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_startButton_clicked();

    void on_stopButton_clicked();

    void serialRecieve();

    void on_tempSlider_valueChanged(int value);

    void on_voltageSlider_valueChanged(int value);

private:
    Ui::MainWindow *ui;
    QSerialPort *serial;
    char status;
    char address;

    void setStatus(char status);

    void setAddress(char address);

    QByteArray getError(char action);

    QByteArray getConnectData();

    QByteArray getData();

    QByteArray getSuccessData();

    void displayData(QByteArray & ba);

    void disableUI();

    void setDefaultUI();

    const unsigned int CONFIG_SIZE = 4;
    const unsigned int DATA_SIZE = 8;
    const unsigned int DATA_INDEX = 4;
    const float ATT_STEP = 0.1;
    const int ATT_MIN = 0;

    const float TEMP_STEP = 0.5;
    const int TEMP_MIN = -110;
    const float VOLTAGE_STEP = 0.1;
    const int VOLTAGE_MIN = 0;
};
#endif // MAINWINDOW_H
