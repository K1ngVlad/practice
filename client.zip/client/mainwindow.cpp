#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QSerialPort>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    serial = new QSerialPort(this);

    connect(serial, SIGNAL(readyRead()), this, SLOT(serialRecieve()));

    setAddress(0);
    setStatus(0);

    setDefaultUI();
}

MainWindow::~MainWindow()
{
    delete ui;

    serial->close();
    delete serial;
}

void MainWindow::setStatus(char status) {
    this->status = status;
}

void MainWindow::setAddress(char address) {
    this->address = address;
}

void MainWindow::setDefaultUI() {

    ui->connectButton->setDisabled(false);
    ui->disconnectButton->setDisabled(true);

    ui->textStatus->setText("Выключен");

    ui->portSelect->clear();

    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts()) {
        QSerialPort port;
        port.setPort(info);
        ui->portSelect->addItem(info.portName());
        if(port.open(QIODevice::ReadWrite)) {
            qDebug() << "Название: " + info.portName() + " " + info.description() + " " + info.manufacturer() << "\n";
        }
    }

    ui->speedSelect->clear();

    ui->speedSelect->addItem("1200 baud");
    ui->speedSelect->addItem("2400 baud");
    ui->speedSelect->addItem("4800 baud");
    ui->speedSelect->addItem("9600 baud");
    ui->speedSelect->addItem("19200 baud");
    ui->speedSelect->addItem("38400 baud");
    ui->speedSelect->addItem("57600 baud");
    ui->speedSelect->addItem("115200 baud");

    ui->speedSelect->setCurrentIndex(ui->speedSelect->findText("9600 baud"));

    qDebug() << ui->speedSelect->findText("9600 baud");

    ui->firstAttSlider->setMinimum(0);
    ui->firstAttSlider->setMaximum(310);
    ui->secondAttSlider->setMinimum(0);
    ui->secondAttSlider->setMaximum(310);

    ui->moduleText->setText("");
    ui->sourceText->setText("");
    ui->romText->setText("");
    ui->tempText->setText("");
    ui->voltageText->setText("");
    ui->firstAttText->setText("");
    ui->secondAttText->setText("");
    ui->reservText->setText("");

    ui->rangeText->setText("");

    ui->majorVersion->setNum(0);
    ui->minorVersion->setNum(0);

    ui->temp->setText("");
    ui->voltage->setText("");

    ui->speedSelect->setDisabled(false);
    ui->portSelect->setDisabled(false);
}

QByteArray MainWindow::getConnectData() {
    QByteArray data;
    data.resize(CONFIG_SIZE);
    data[0] = address;
    data[1] = 0;
    data[2] = 0;
    data[3] = 0;
    return data;
}

QByteArray MainWindow::getReadData() {
    QByteArray data;
    data.resize(CONFIG_SIZE);
    data[0] = address;
    data[1] = 1;
    data[2] = 0;
    data[3] = 0;
    return data;
}

QByteArray MainWindow::getWriteData() {
    QByteArray data;
    data.resize(CONFIG_SIZE + DATA_SIZE);
    data[0] = address;
    data[1] = 2;
    data[2] = 1;
    data[3] = DATA_SIZE;
    data[4] = 0;
    data[4] = ui->check_1_1->isChecked() ? (1 << 0) | data[4] : data[4];
    data[4] = ui->check_1_2->isChecked() ? (1 << 1) | data[4] : data[4];
    data[4] = ui->check_1_3->isChecked() ? (1 << 2) | data[4] : data[4];
    data[4] = ui->check_1_4->isChecked() ? (1 << 3) | data[4] : data[4];
    data[4] = ui->check_1_5->isChecked() ? (1 << 4) | data[4] : data[4];
    data[4] = ui->check_1_6->isChecked() ? (1 << 5) | data[4] : data[4];
    data[4] = ui->check_1_7->isChecked() ? (1 << 6) | data[4] : data[4];
    data[4] = ui->check_1_8->isChecked() ? (1 << 7) | data[4] : data[4];
    data[5] = 0;
    data[5] = ui->check_2_1->isChecked() ? (1 << 0) | data[5] : data[5];
    data[5] = ui->check_2_2->isChecked() ? (1 << 1) | data[5] : data[5];
    data[5] = ui->check_2_3->isChecked() ? (1 << 2) | data[5] : data[5];
    data[5] = ui->check_2_4->isChecked() ? (1 << 3) | data[5] : data[5];
    data[5] = ui->check_2_5->isChecked() ? (1 << 4) | data[5] : data[5];
    data[5] = ui->check_2_6->isChecked() ? (1 << 5) | data[5] : data[5];
    data[5] = ui->check_2_7->isChecked() ? (1 << 6) | data[5] : data[5];
    data[5] = ui->check_2_8->isChecked() ? (1 << 7) | data[5] : data[5];

    int firstAtt = ui->firstAttSlider->value();
    unsigned char* firstAttBytes = (unsigned char*)&firstAtt;
    data[6] = firstAttBytes[0];
    data[7] = firstAttBytes[1];

    int secondAtt = ui->secondAttSlider->value();
    unsigned char* secondAttBytes = (unsigned char*)&secondAtt;
    data[8] = secondAttBytes[0];
    data[9] = secondAttBytes[1];

    return data;
}

void MainWindow::displayData(QByteArray & ba) {
    const int DATA_SIZE = ba[3];

    int temp = 0;
    int voltage = 0;

    for(int i = 0; i < DATA_SIZE; i++) {
        switch (i) {
            case 0:
            switch (ba[DATA_INDEX + i]) {
                case (char) 0:
                    ui->rangeText->setText("Штатный");
                    break;
                case (char) 1:
                    ui->rangeText->setText("Контроль");
                    break;
                case (char) 2:
                    ui->rangeText->setText("Калибровка");
                    break;
                case (char) 3:
                    ui->rangeText->setText("Загрузчик");
                    break;
                default:
                    ui->rangeText->setText("");
            }
                break;
            case 1:
                ui->moduleText->setText((1 << 0 & ba[DATA_INDEX + i]) ? "Исправен" : "Не исправен");
                ui->sourceText->setText((1 << 1 & ba[DATA_INDEX + i]) ? "Исправен" : "Не исправен");
                ui->romText->setText((1 << 2 & ba[DATA_INDEX + i]) ? "Исправен" : "Не исправен");
                ui->tempText->setText((1 << 3 & ba[DATA_INDEX + i]) ? "Исправен" : "Не исправен");
                ui->voltageText->setText((1 << 4 & ba[DATA_INDEX + i]) ? "Исправен" : "Не исправен");
                ui->firstAttText->setText((1 << 5 & ba[DATA_INDEX + i]) ? "Исправен" : "Не исправен");
                ui->secondAttText->setText((1 << 6 & ba[DATA_INDEX + i]) ? "Исправен" : "Не исправен");
                ui->reservText->setText((1 << 7 & ba[DATA_INDEX + i]) ? "Исправен" : "Не исправен");
                break;
            case 2:
                temp = (unsigned char) ba[DATA_INDEX + i];
                break;
            case 3:
                temp = temp + ((unsigned char) ba[DATA_INDEX + i]) * 256;
                break;
            case 4:
                voltage = (unsigned char) ba[DATA_INDEX + i];
                break;
            case 5:
                voltage = voltage + ((unsigned char) ba[DATA_INDEX + i]) * 256;
                break;
            case 6:
                ui->majorVersion->setNum(ba[DATA_INDEX + i]);
                break;
            case 7:
                ui->minorVersion->setNum(ba[DATA_INDEX + i]);
                break;
        }
    }

    ui->temp->setNum(TEMP_MIN + temp * TEMP_STEP);
    ui->voltage->setNum(VOLTAGE_MIN + voltage * VOLTAGE_STEP);
}

void MainWindow::serialRecieve() {
    if(status == 0) return;

    QByteArray ba = serial->readAll();

    if(address && (ba[0] == address)) {
        if(ba[2] == (char) 1) {
            setDefaultUI();
            setStatus(0);
            setAddress(0);
            qDebug() << "Произошла ошибка\n";
            return;
        }

        switch (ba[1]) {
            case (char) 0:
                ui->textStatus->setText("Подключён");
                setStatus(2);
                serial->write(getReadData());
                break;
            case (char) 1:
                if(status == 2) {
                    displayData(ba);
                    serial->write(getWriteData());
                }
                break;
            case (char) 2:
                if(status == 2) {
                    serial->write(getReadData());
                }
                break;
        }
    }

}

void MainWindow::on_connectButton_clicked()
{
    QString portName = ui->portSelect->currentText();
    char address = ui->addressInput->text().toInt();

    serial->setPortName(portName);

    switch (ui->speedSelect->currentIndex()) {
        case 0:
            serial->setBaudRate(QSerialPort::Baud1200);
            break;
        case 1:
            serial->setBaudRate(QSerialPort::Baud2400);
            break;
        case 2:
            serial->setBaudRate(QSerialPort::Baud4800);
            break;
        case 3:
            serial->setBaudRate(QSerialPort::Baud9600);
            break;
        case 4:
            serial->setBaudRate(QSerialPort::Baud19200);
            break;
        case 5:
            serial->setBaudRate(QSerialPort::Baud38400);
            break;
        case 6:
            serial->setBaudRate(QSerialPort::Baud57600);
            break;
        case 7:
            serial->setBaudRate(QSerialPort::Baud115200);
            break;
        default:
            serial->setBaudRate(QSerialPort::Baud9600);
    }

    serial->setBaudRate(QSerialPort::Baud9600);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->open(QIODevice::ReadWrite);

    setStatus(1);
    setAddress(address);

    ui->connectButton->setDisabled(true);
    ui->disconnectButton->setDisabled(false);
    ui->textStatus->setText("Ожидание");

    ui->speedSelect->setDisabled(true);
    ui->portSelect->setDisabled(true);

    serial->write(getConnectData());
}

void MainWindow::on_disconnectButton_clicked()
{
    setDefaultUI();
    setStatus(0);
    setAddress(0);
    serial->close();
}
