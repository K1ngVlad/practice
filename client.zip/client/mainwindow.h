#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QSerialPortInfo>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void serialRecieve();

    void on_connectButton_clicked();

    void on_disconnectButton_clicked();

private:
    Ui::MainWindow *ui;
    QSerialPort *serial;
    char status;
    char address;
    char waitingDataType;

    void setStatus(char status);

    void setAddress(char address);

    QByteArray getConnectData();

    QByteArray getReadData();

    QByteArray getWriteData();

    void displayData(QByteArray & ba);

    void setDefaultUI();

    const unsigned int CONFIG_SIZE = 4;
    const unsigned int DATA_SIZE = 6;
    const unsigned int DATA_INDEX = 4;
    const float TEMP_STEP = 0.5;
    const int TEMP_MIN = -110;
    const float VOLTAGE_STEP = 0.1;
    const int VOLTAGE_MIN = 0;
};
#endif // MAINWINDOW_H
